create
    definer = root@localhost procedure routine1(OUT var_customer varchar(45))
BEGIN
		Select * 
        from Customer;
END;

